<?php
   /*
   Plugin Name: Tubular Lead Builder
   Plugin URI: https://www.tubular.io
   Description: Tubular lead builder simplifies adding script from tubular for lead builder
   Version: 1.0
   Author: Tubular.io
   Author URL: https://www.tubular.io
   License: GPL2
   */
  
class TubularLeadBuilder
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
        add_action( 'wp_footer', array( $this, 'tblr_lead_builder_add_script' ) );
    }

    public function tblr_lead_builder_add_script()
    {
        $options = get_option( 'tubular-lead-builder-script' );
        $script_enq = $options['script_id'];
        echo $script_enq . "";
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Settings Admin', 
            'Tubular Lead Builder', 
            'manage_options', 
            'tubular-lead-builder', 
            array( $this, 'create_admin_page' )
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'tubular-lead-builder-script' );
        ?>
        <div class="wrap">
            <h1>Tubular Lead Builder Settings</h1>
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'tubular-lead-builder-group' );
                do_settings_sections( 'tubular-lead-builder' );
                submit_button();
            ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'tubular-lead-builder-group', // Option group
            'tubular-lead-builder-script', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'builder_section_id', // ID
            'Tubular Lead Builder Settings', // Title
            array( $this, 'print_section_info' ), // Callback
            'tubular-lead-builder' // Page
        );  

        add_settings_field(
            'tubular_lead_builder_script', // ID
            'Paste Script', // Title 
            array( $this, 'id_number_callback' ), // Callback
            'tubular-lead-builder', // Page
            'builder_section_id' // Section           
        );          
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['script_id'] ) )
            $new_input['script_id'] = $input['script_id'] ;


        return $new_input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print '';
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function id_number_callback()
    {
        printf(
            '<input type="text" style="width: 600px; height: 30px;" id="id_number" name="tubular-lead-builder-script[script_id]" value="%s" />',
            isset( $this->options['script_id'] ) ? esc_attr( $this->options['script_id']) : ''
        );
    }


}

$my_settings_page = new TubularLeadBuilder();